public class Room {
    boolean states;
    String id;
    int seat_count;
//    public void addRoom()
//    {
//
//    }
}
