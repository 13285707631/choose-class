public class Control {
    public  static void main(String args[])
    {
        Start s=new Start();
        s.start();
    }

}
