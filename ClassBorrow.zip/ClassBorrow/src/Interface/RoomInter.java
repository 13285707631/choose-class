package Interface;

public interface RoomInter {
    public  void addRoom();
    public void delRoom();
}
