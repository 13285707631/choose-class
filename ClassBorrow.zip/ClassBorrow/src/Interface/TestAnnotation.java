package Interface;

public @interface TestAnnotation{
}
